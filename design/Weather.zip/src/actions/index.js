import axios from 'axios';

const API_KEY = '898a680be5c2808cea11f9778fc33282';
const API_URL = `http://api.openweathermap.org/data/2.5/forecast?APPID=${API_KEY}`;

export const FETCH_WEATHER = 'FETCH_WEATHER';

export function fetchWeather(city) {
    const url = `${API_URL}&q=${city},US`;
    const request = axios.get(url);

    return {
        type: FETCH_WEATHER,
        payload: request
    }
}